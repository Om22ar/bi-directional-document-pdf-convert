import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Enable JSON body parsing with a high limit for document images
app.use(express.json({ limit: "50mb" }));

// Initialize Gemini API Client
const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// AI OCR Endpoint for PDF pages (images)
app.post("/api/gemini/ocr", async (req, res) => {
  try {
    let { imageBase64, imageUrl, mimeType = "image/png" } = req.body;

    if (!apiKey) {
      return res.status(500).json({
        error: "GEMINI_API_KEY is not configured on the server. Please add it in Secrets.",
      });
    }

    // Case 1: Fetch and convert remote imageUrl if provided
    if (imageUrl) {
      console.log(`[OCR Server] Fetching remote image from URL: ${imageUrl}`);
      try {
        const fetchResponse = await fetch(imageUrl);
        if (!fetchResponse.ok) {
          throw new Error(`Failed to fetch remote image. HTTP Status: ${fetchResponse.status}`);
        }
        
        const contentType = fetchResponse.headers.get("content-type");
        if (contentType) {
          mimeType = contentType;
        }
        
        const arrayBuffer = await fetchResponse.arrayBuffer();
        imageBase64 = Buffer.from(arrayBuffer).toString("base64");
        console.log(`[OCR Server] Successfully converted remote image to base64. MimeType: ${mimeType}`);
      } catch (fetchErr: any) {
        console.error("[OCR Server] Remote image fetch error:", fetchErr);
        return res.status(400).json({
          error: `Unable to download image from the provided URL: ${fetchErr.message}`
        });
      }
    }

    if (!imageBase64) {
      return res.status(400).json({ error: "Missing imageBase64 or imageUrl in request body." });
    }

    // Extract mimeType from base64 if it's a Data URL
    if (typeof imageBase64 === "string" && imageBase64.startsWith("data:")) {
      const match = imageBase64.match(/^data:([^;]+);base64,/);
      if (match) {
        mimeType = match[1];
        imageBase64 = imageBase64.substring(match[0].length);
      }
    }

    // Clean up base64 string (strip prefixes like 'data:image/png;base64,')
    if (typeof imageBase64 === "string" && imageBase64.includes(",")) {
      imageBase64 = imageBase64.split(",")[1];
    }
    // Remove any potential whitespace or newlines
    imageBase64 = imageBase64.trim().replace(/\s/g, "");

    // Normalize and sanitize mimeType for Gemini Compatibility
    // Supported: image/png, image/jpeg, image/webp, image/heic, image/heif
    let normalizedMimeType = mimeType.toLowerCase().trim();
    if (normalizedMimeType === "image/jpg") {
      normalizedMimeType = "image/jpeg";
    }
    const supportedMimeTypes = ["image/png", "image/jpeg", "image/webp", "image/heic", "image/heif"];
    if (!supportedMimeTypes.includes(normalizedMimeType)) {
      console.warn(`[OCR Server] Unsupported mimeType: "${normalizedMimeType}". Defaulting to "image/jpeg".`);
      normalizedMimeType = "image/jpeg";
    }

    // Prepare content parts for Gemini (using the recommended gemini-3.5-flash model)
    const imagePart = {
      inlineData: {
        mimeType: normalizedMimeType,
        data: imageBase64,
      },
    };

    const promptPart = {
      text: "Extract all text from this page image with absolute high precision. Maintain original paragraphs, structural layouts, tables (if any, as Markdown), and punctuation. Do not add summaries or notes.",
    };

    // Call the Gemini model (gemini-3.5-flash is the modern successor to gemini-1.5-flash)
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts: [imagePart, promptPart] },
    });

    const extractedText = response.text || "";
    return res.json({ text: extractedText });
  } catch (error: any) {
    console.error("Gemini OCR server error:", error);
    return res.status(500).json({
      error: error.message || "An error occurred during Gemini OCR text extraction.",
    });
  }
});

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "healthy", timestamp: new Date().toISOString() });
});

async function startServer() {
  // Vite dev middleware or static serving
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();

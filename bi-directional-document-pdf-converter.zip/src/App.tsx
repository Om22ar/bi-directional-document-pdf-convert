import React, { useState } from "react";
import InteractiveWorkspace from "./components/InteractiveWorkspace";
import FlutterCodeHub from "./components/FlutterCodeHub";
import ArchitectureBlueprint from "./components/ArchitectureBlueprint";
import { Cpu, Terminal, Layers, BookOpen, ExternalLink, HelpCircle, Code2, Play, Circle } from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<"interactive" | "codebase" | "architecture">("interactive");

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans select-none antialiased">
      
      {/* Top Banner and Navigation mirroring Geometric Balance design */}
      <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 sm:px-8 shrink-0 sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl w-full mx-auto flex items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            {/* Geometric logo: Blue square with rotated white square inside */}
            <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center shadow-sm">
              <div className="w-4 h-4 bg-white rotate-45 rounded-sm"></div>
            </div>
            <div>
              <span className="font-bold text-lg sm:text-xl text-slate-800 tracking-tight">
                AI <span className="text-blue-600">DocConverter</span> Pro
              </span>
              <span className="hidden md:inline-block text-xs text-slate-400 font-medium ml-3 border-l border-slate-200 pl-3">
                Flutter Workspace & Simulator
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Dynamic Status Indicator */}
            <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-slate-100 rounded-full border border-slate-200">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-xs font-medium text-slate-600">Gemini OCR Pipeline: Online</span>
            </div>

            {/* Navigation Tabs */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200/60">
              <button
                onClick={() => setActiveTab("interactive")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
                  activeTab === "interactive"
                    ? "bg-white text-blue-600 shadow-sm border border-slate-200"
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                <Play className="w-3.5 h-3.5" />
                <span>Playground</span>
              </button>
              <button
                onClick={() => setActiveTab("codebase")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
                  activeTab === "codebase"
                    ? "bg-white text-blue-600 shadow-sm border border-slate-200"
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                <Code2 className="w-3.5 h-3.5" />
                <span>Source Code</span>
              </button>
              <button
                onClick={() => setActiveTab("architecture")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
                  activeTab === "architecture"
                    ? "bg-white text-blue-600 shadow-sm border border-slate-200"
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Architecture</span>
              </button>
            </div>
          </div>

        </div>
      </header>

      {/* Main Workspace Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 flex flex-col gap-6">
        
        {/* Dynamic Context Header */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
          {activeTab === "interactive" && (
            <div className="flex flex-col gap-1.5">
              <h2 className="text-lg font-extrabold text-slate-800 tracking-tight flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded bg-blue-600"></span>
                Live Bidirectional Conversion Playground
              </h2>
              <p className="text-xs text-slate-500 max-w-4xl leading-relaxed">
                Configure formatting, paste raw text inputs, or load assets from remote endpoints to generate high-fidelity multi-page PDFs using our precise page margin layout engine. For scanned documents or custom images, trigger our real-time OCR extraction powered by Gemini.
              </p>
            </div>
          )}

          {activeTab === "codebase" && (
            <div className="flex flex-col gap-1.5">
              <h2 className="text-lg font-extrabold text-slate-800 tracking-tight flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded bg-blue-600"></span>
                Flutter Android Studio Codebase Explorer
              </h2>
              <p className="text-xs text-slate-500 max-w-4xl leading-relaxed">
                Browse the complete source code matching your requested folder architecture. These files utilize the latest packages (<span className="text-blue-600 font-semibold">google_generative_ai</span>, <span className="text-blue-600 font-semibold">pdf</span>, <span className="text-blue-600 font-semibold">syncfusion_flutter_pdfviewer</span>) and follow best-practice separation of concerns (Presentation, Domain, Data) utilizing Flutter Riverpod state management.
              </p>
            </div>
          )}

          {activeTab === "architecture" && (
            <div className="flex flex-col gap-1.5">
              <h2 className="text-lg font-extrabold text-slate-800 tracking-tight flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded bg-blue-600"></span>
                Mobile Document Processing Architecture Blueprint
              </h2>
              <p className="text-xs text-slate-500 max-w-4xl leading-relaxed">
                Examine technical diagrams and documentation detailing the offloading concurrency mechanics, memory leakage avoidances, and sequential streaming page pipelines designed to run efficiently on high-volume production mobile applications.
              </p>
            </div>
          )}
        </div>

        {/* Content Panel Renderer */}
        <div className="flex-1">
          {activeTab === "interactive" && <InteractiveWorkspace />}
          {activeTab === "codebase" && <FlutterCodeHub />}
          {activeTab === "architecture" && <ArchitectureBlueprint />}
        </div>

      </main>

      {/* Footer mirroring Geometric Balance design */}
      <footer className="h-12 bg-slate-800 flex items-center justify-between px-6 sm:px-8 text-[10px] text-slate-400 uppercase tracking-widest shrink-0">
        <div className="flex gap-6">
          <span>PDF Package: v3.11.1</span>
          <span>Syncfusion PDF: v25.2.7</span>
          <span>Generative AI: v0.4.1</span>
        </div>
        <div className="hidden sm:flex gap-6">
          <span>Storage Available: 4.2 GB</span>
          <span className="text-emerald-400 font-bold">Architecture: Clean Layers</span>
        </div>
      </footer>

    </div>
  );
}

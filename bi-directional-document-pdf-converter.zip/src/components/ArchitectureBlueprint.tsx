import React from "react";
import { Layers, ShieldAlert, Cpu, Network, Zap, BookOpen } from "lucide-react";

export default function ArchitectureBlueprint() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      {/* Block 1: Clean Architecture layers */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col gap-4 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded bg-blue-50 text-blue-600 shrink-0">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-800">Clean Architecture Stack</h4>
            <p className="text-[11px] text-slate-400 font-medium">Strict dependency direction</p>
          </div>
        </div>

        <p className="text-xs text-slate-500 leading-relaxed">
          The Flutter solution implements a strict 3-tier **Clean Architecture** stack (Presentation, Domain, Data) ensuring loose coupling and perfect testability:
        </p>

        <div className="flex flex-col gap-2 font-mono text-[11px] mt-2">
          <div className="bg-slate-50 p-2.5 rounded border border-slate-200 shadow-sm">
            <span className="text-blue-600 font-bold">PRESENTATION (UI & State)</span>
            <p className="text-slate-500 text-[10px] mt-0.5">Widget screens and Riverpod StateNotifiers reacting to user clicks.</p>
          </div>
          <div className="bg-slate-50 p-2.5 rounded border border-slate-200 shadow-sm">
            <span className="text-indigo-600 font-bold">DOMAIN (Business Logic)</span>
            <p className="text-slate-500 text-[10px] mt-0.5">Entities (ConversionJob) and Repository Contracts with zero platform dependencies.</p>
          </div>
          <div className="bg-slate-50 p-2.5 rounded border border-slate-200 shadow-sm">
            <span className="text-emerald-600 font-bold">DATA (External Services)</span>
            <p className="text-slate-500 text-[10px] mt-0.5">Layout Engines, Gemini API OCR implementations, and system directory writers.</p>
          </div>
        </div>
      </div>

      {/* Block 2: Memory Safety & Streaming */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col gap-4 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded bg-emerald-50 text-emerald-600 shrink-0">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-800">Dynamic Streaming & Memory</h4>
            <p className="text-[11px] text-slate-400 font-medium">OOM Avoidance Protocol</p>
          </div>
        </div>

        <p className="text-xs text-slate-500 leading-relaxed">
          Processing massive multi-page PDFs on mobile is highly prone to Out-of-Memory (OOM) crashes. This codebase solves that through an **incremental pipeline**:
        </p>

        <div className="flex flex-col gap-3 mt-1.5 text-xs">
          <div className="flex gap-3">
            <div className="flex flex-col items-center">
              <span className="w-5 h-5 rounded-full bg-slate-100 flex items-center justify-center font-bold font-mono text-[10px] text-slate-600 border border-slate-200">1</span>
              <div className="w-0.5 flex-1 bg-slate-200 my-1" />
            </div>
            <div>
              <p className="font-bold text-slate-700">Page-by-Page Streaming</p>
              <p className="text-[10px] text-slate-400">Instead of loading the entire document, the PDF is read iteratively. One page is parsed, converted to text, and immediately garbage-collected.</p>
            </div>
          </div>

          <div className="flex gap-3">
            <div className="flex flex-col items-center">
              <span className="w-5 h-5 rounded-full bg-slate-100 flex items-center justify-center font-bold font-mono text-[10px] text-slate-600 border border-slate-200">2</span>
              <div className="w-0.5 flex-1 bg-slate-200 my-1" />
            </div>
            <div>
              <p className="font-bold text-slate-700">Garbage Collection Release</p>
              <p className="text-[10px] text-slate-400">Each page's high-DPI image buffer is closed explicitly (`page.close()`) after rasterization is fed into Gemini to clear native OS graphics handles.</p>
            </div>
          </div>

          <div className="flex gap-3">
            <div className="flex flex-col items-center">
              <span className="w-5 h-5 rounded-full bg-slate-100 flex items-center justify-center font-bold font-mono text-[10px] text-slate-600 border border-slate-200">3</span>
            </div>
            <div>
              <p className="font-bold text-slate-700">String Buffer Aggregation</p>
              <p className="text-[10px] text-slate-400">Extracted markdown paragraphs are appended to a lightweight `StringBuffer` rather than generating multiple separate intermediate disk files.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Block 3: Isolates Thread Offloading */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col gap-4 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded bg-indigo-50 text-indigo-600 shrink-0">
            <Cpu className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-800">Dart Isolates Threading</h4>
            <p className="text-[11px] text-slate-400 font-medium">Zero UI Thread Jitter</p>
          </div>
        </div>

        <p className="text-xs text-slate-500 leading-relaxed">
          Flutter runs on a single main thread. Executing raw base64 graphics conversion or OCR token formatting on it would cause the UI to freeze (frame drops).
        </p>

        <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 flex flex-col gap-3 shadow-inner">
          <div className="flex items-center justify-between text-[11px] font-mono border-b border-slate-200 pb-2">
            <span className="text-slate-600 font-bold">MAIN ISOLATE (UI)</span>
            <span className="text-slate-400 font-semibold">&gt;&gt; Spawn compute() &gt;&gt;</span>
          </div>
          <p className="text-[10px] text-slate-500 leading-relaxed">
            The presentation thread remains completely free to run animations at 60fps, while the background thread handles image bytes.
          </p>
          <div className="flex items-center justify-between text-[11px] font-mono border-t border-slate-200 pt-2 text-indigo-600 font-bold">
            <span>BACKGROUND THREAD</span>
            <span>Handles Gemini payload parsing</span>
          </div>
        </div>

        <div className="flex items-center gap-2 text-[10px] text-blue-600 font-bold uppercase tracking-wide">
          <Zap className="w-3.5 h-3.5" />
          <span>Keeps frame rate steady during heavy visual compilation</span>
        </div>
      </div>

      {/* Block 4: Detailed Flow Description */}
      <div className="lg:col-span-3 bg-white border border-slate-200 rounded-xl p-6 flex flex-col sm:flex-row items-start gap-4 shadow-sm">
        <div className="p-3 rounded-lg bg-blue-50 text-blue-600 shrink-0">
          <BookOpen className="w-6 h-6" />
        </div>
        <div>
          <h4 className="text-sm font-bold text-slate-800">Sequential Conversion Pipeline Mechanics</h4>
          <p className="text-xs text-slate-500 mt-2 leading-relaxed">
            When converting PDF to Document: The repository first initializes the `PdfDocument` to count pages. For each page, it streams a progress update, opens the page sequentially, renders it at high-DPI resolution to PNG bytes to maintain table layouts and paragraph text accurately, and dispatches the bytes to the `GeminiOcrService`. The model parses the rasterized images on its cloud server (offloading CPU heavy lifting from the mobile client), and returns cleanly structured markdown texts.
          </p>
          <p className="text-xs text-slate-500 mt-2 leading-relaxed">
            When converting Document to PDF: The layout engine handles text measuring, dynamically calculates where lines break based on your margins and fonts, and creates pages on the fly using `MultiPage` widgets, ensuring standard legal headers, titles, and dynamic footers are placed correctly on each sheet.
          </p>
        </div>
      </div>

    </div>
  );
}

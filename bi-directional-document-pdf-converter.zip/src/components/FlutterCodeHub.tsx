import React, { useState } from "react";
import { FLUTTER_CODEBASE } from "../data/flutter_codebase";
import { FolderOpen, FileCode, Copy, Check, Download, Layers, ShieldCheck, Heart } from "lucide-react";

export default function FlutterCodeHub() {
  const [selectedFileIdx, setSelectedFileIdx] = useState(0);
  const [copied, setCopied] = useState(false);

  const activeFile = FLUTTER_CODEBASE[selectedFileIdx];

  const handleCopy = () => {
    navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([activeFile.content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = activeFile.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm flex flex-col lg:flex-row min-h-[620px]">
      
      {/* File Tree Sidebar */}
      <div className="w-full lg:w-80 bg-slate-50 border-r border-slate-200 p-5 flex flex-col gap-4">
        <div>
          <div className="flex items-center gap-2 text-slate-800 font-bold text-sm">
            <FolderOpen className="w-4 h-4 text-blue-600" />
            <span>Flutter Android Workspace</span>
          </div>
          <p className="text-xs text-slate-400 mt-1">Clean Architecture Modules</p>
        </div>

        {/* Project directory layout list */}
        <div className="flex-1 overflow-y-auto max-h-[500px] flex flex-col gap-1.5 pr-2 custom-scrollbar">
          {FLUTTER_CODEBASE.map((file, idx) => (
            <button
              key={file.path}
              onClick={() => {
                setSelectedFileIdx(idx);
                setCopied(false);
              }}
              className={`w-full flex items-start gap-3 p-2.5 rounded text-left transition ${
                selectedFileIdx === idx
                  ? "bg-blue-50/50 border border-blue-200 text-blue-700"
                  : "border border-transparent text-slate-600 hover:text-slate-850 hover:bg-slate-100"
              }`}
            >
              <FileCode className={`w-4 h-4 mt-0.5 shrink-0 ${selectedFileIdx === idx ? "text-blue-600" : "text-slate-400"}`} />
              <div className="overflow-hidden">
                <p className="text-xs font-bold font-mono truncate">{file.name}</p>
                <p className="text-[10px] text-slate-400 truncate mt-0.5">{file.path}</p>
              </div>
            </button>
          ))}
        </div>

        <div className="pt-4 border-t border-slate-200 text-center">
          <p className="text-[10px] text-slate-400 flex items-center justify-center gap-1 font-bold uppercase tracking-wider">
            <Heart className="w-3 h-3 text-rose-500 fill-rose-500 animate-pulse" />
            Designed for Android Studio
          </p>
        </div>
      </div>

      {/* Main Code Viewport */}
      <div className="flex-1 flex flex-col bg-white">
        
        {/* Top bar with file meta and actions */}
        <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-50/50">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold px-2 py-0.5 rounded bg-slate-200 text-slate-700 font-mono uppercase">
                {activeFile.language}
              </span>
              <h4 className="text-sm font-bold text-slate-800 font-mono truncate">{activeFile.path}</h4>
            </div>
            <p className="text-xs text-slate-500 mt-1 font-medium">{activeFile.description}</p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleCopy}
              className="bg-white hover:bg-slate-50 text-slate-700 text-xs px-3.5 py-2 rounded font-bold flex items-center gap-1.5 transition border border-slate-200 shadow-sm"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-400">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy</span>
                </>
              )}
            </button>
            <button
              onClick={handleDownloadFile}
              className="bg-slate-800 hover:bg-slate-950 text-white text-xs px-3.5 py-2 rounded font-bold flex items-center gap-1.5 transition shadow"
            >
              <Download className="w-3.5 h-3.5" />
              Download File
            </button>
          </div>
        </div>

        {/* The Code block display */}
        <div className="flex-1 p-5 overflow-auto bg-slate-900 border-b border-slate-950 relative">
          <pre className="text-xs text-slate-300 font-mono leading-relaxed select-text whitespace-pre overflow-x-auto select-all selection:bg-blue-500/20 selection:text-blue-200">
            <code>{activeFile.content}</code>
          </pre>
        </div>

        {/* Bottom architecture meta */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-wide">
            <Layers className="w-3.5 h-3.5 text-blue-600" />
            <span>Clean Architecture: layers separated strictly following Separation of Concerns</span>
          </div>
          <div className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 uppercase tracking-wide">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Ready to compile</span>
          </div>
        </div>

      </div>
    </div>
  );
}

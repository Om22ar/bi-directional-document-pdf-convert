import { FlutterFile } from "../types";

export const FLUTTER_CODEBASE: FlutterFile[] = [
  {
    path: "pubspec.yaml",
    name: "pubspec.yaml",
    language: "yaml",
    description: "App metadata, Flutter configurations, and exact dependency declarations.",
    content: `name: flutter_pdf_converter
description: "A production-ready bi-directional document converter featuring Gemini OCR and layouts."
version: 1.0.0+1

environment:
  sdk: ">=3.0.0 <4.0.0"

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.6
  
  # State Management
  flutter_riverpod: ^2.5.1
  
  # Google AI SDK
  google_generative_ai: ^0.4.1
  
  # File Processing & Utilities
  pdf: ^3.11.1
  file_picker: ^8.0.3
  path_provider: ^2.1.3
  pdfx: ^2.6.0 # For PDF rendering / rasterization during image-based OCR
  syncfusion_flutter_pdfviewer: ^25.2.7 # To preview PDFs securely

dev_dependencies:
  flutter_test:
    sdk: flutter
  integration_test:
    sdk: flutter

flutter:
  uses-material-design: true
  assets:
    - assets/
`
  },
  {
    path: "android/app/src/main/AndroidManifest.xml",
    name: "AndroidManifest.xml",
    language: "xml",
    description: "Android manifest configured with internet, storage permissions, and URL queries.",
    content: `<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />

    <application
        android:label="PDF Converter & AI OCR"
        android:name="\${applicationName}"
        android:icon="@mipmap/ic_launcher">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|screenLayout|density|locale"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">
            <meta-data
              android:name="io.flutter.embedding.android.NormalTheme"
              android:resource="@style/NormalTheme"
              />
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
        <meta-data
            android:name="flutterEmbedding"
            android:value="2" />
    </application>
</manifest>`
  },
  {
    path: "lib/main.dart",
    name: "main.dart",
    language: "dart",
    description: "App entry point initialized with Riverpod ProviderScope.",
    content: `import 'package:flutter/material';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'presentation/screens/converter_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    // Wrap application with ProviderScope for Riverpod state management
    const ProviderScope(
      child: FileConverterApp(),
    ),
  );
}

class FileConverterApp extends StatelessWidget {
  const FileConverterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Document Converter',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0F172A), // Elegant deep slate
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const ConverterScreen(),
    );
  }
}`
  },
  {
    path: "lib/domain/models/document_model.dart",
    name: "document_model.dart",
    language: "dart",
    description: "Plain Dart Immutable Domain Model representing files and current processing meta.",
    content: `enum ConversionType { docToPdf, pdfToDoc }

class ConversionJob {
  final String id;
  final String sourcePath;
  final String? sourceUrl;
  final String? outputPath;
  final String fileName;
  final ConversionType type;
  final double progress; // 0.0 to 1.0
  final String? errorMessage;
  final bool isCompleted;

  const ConversionJob({
    required this.id,
    required this.sourcePath,
    this.sourceUrl,
    this.outputPath,
    required this.fileName,
    required this.type,
    required this.progress,
    this.errorMessage,
    required this.isCompleted,
  });

  ConversionJob copyWith({
    String? id,
    String? sourcePath,
    String? sourceUrl,
    String? outputPath,
    String? fileName,
    ConversionType? type,
    double? progress,
    String? errorMessage,
    bool? isCompleted,
  }) {
    return ConversionJob(
      id: id ?? this.id,
      sourcePath: sourcePath ?? this.sourcePath,
      sourceUrl: sourceUrl ?? this.sourceUrl,
      outputPath: outputPath ?? this.outputPath,
      fileName: fileName ?? this.fileName,
      type: type ?? this.type,
      progress: progress ?? this.progress,
      errorMessage: errorMessage ?? this.errorMessage,
      isCompleted: isCompleted ?? this.isCompleted,
    );
  }
}`
  },
  {
    path: "lib/domain/repositories/conversion_repository.dart",
    name: "conversion_repository.dart",
    language: "dart",
    description: "Repository contract definition for bi-directional converters following DIP.",
    content: `import 'dart:io';
import '../models/document_model.dart';

abstract class ConversionRepository {
  /// Converts plain text document or string to dynamic multi-page PDF using Layout Engine.
  /// Reports stream of progress decimals (0.0 to 1.0)
  Stream<double> convertDocToPdf({
    required String sourcePath,
    required String textContent,
    required String outputFileName,
  });

  /// Converts a PDF document to plain text (OCR) page-by-page.
  /// Automatically falls back to Gemini-1.5-Flash OCR if rasterization is required.
  /// Returns a stream of progress decimals (0.0 to 1.0) and emits the generated final File.
  Stream<double> convertPdfToDoc({
    required String pdfPath,
    required String outputFileName,
    required String apiKey,
    required Function(File) onCompleted,
  });
}`
  },
  {
    path: "lib/data/services/pdf_layout_engine.dart",
    name: "pdf_layout_engine.dart",
    language: "dart",
    description: "Layout engine with page margins, text wrapping, and multi-page generation using 'pdf'.",
    content: `import 'dart:io';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';

class PdfLayoutEngine {
  /// Generates a structured multi-page PDF with high precision layout.
  Future<File> generatePdfFromText({
    required String text,
    required String fileName,
  }) async {
    final pdf = pw.Document();

    // Use standard universal font settings
    final font = pw.Font.helvetica();
    final fontBold = pw.Font.helveticaBold();

    // Split text into paragraphs
    final paragraphs = text.split('\\n\\n');

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.letter,
        margin: const pw.EdgeInsets.all(36), // 0.5 inch margins
        build: (pw.Context context) {
          return [
            // Header
            pw.Container(
              alignment: pw.Alignment.centerRight,
              padding: const pw.EdgeInsets.only(bottom: 10),
              decoration: const pw.BoxDecoration(
                border: pw.Border(bottom: pw.BorderSide(width: 0.5, color: PdfColors.grey)),
              ),
              child: pw.Text(
                'Converted Document',
                style: pw.TextStyle(font: font, fontSize: 10, color: PdfColors.grey600),
              ),
            ),
            pw.SizedBox(height: 20),

            // Content paragraphs
            ...paragraphs.map((p) {
              final trimmed = p.trim();
              if (trimmed.isEmpty) return pw.SizedBox();
              return pw.Paragraph(
                text: trimmed,
                style: pw.TextStyle(
                  font: font,
                  fontSize: 12,
                  lineSpacing: 4.0,
                  color: PdfColors.slate800,
                ),
                margin: const pw.EdgeInsets.only(bottom: 12),
              );
            }),

            // Footer (Handled dynamically by MultiPage but added here too)
          ];
        },
        footer: (pw.Context context) {
          return pw.Container(
            alignment: pw.Alignment.center,
            margin: const pw.EdgeInsets.only(top: 20),
            child: pw.Text(
              'Page \${context.pageNumber} of \${context.pagesCount}',
              style: pw.TextStyle(font: font, fontSize: 9, color: PdfColors.grey400),
            ),
          );
        },
      ),
    );

    // Get the device local documents directory
    final directory = await getApplicationDocumentsDirectory();
    final file = File('\${directory.path}/\$fileName');
    await file.writeAsBytes(await pdf.save());
    return file;
  }
}`
  },
  {
    path: "lib/data/services/gemini_ocr_service.dart",
    name: "gemini_ocr_service.dart",
    language: "dart",
    description: "Gemini SDK service handling system prompts, model invocation, and visual extraction.",
    content: `import 'dart:typed_data';
import 'package:google_generative_ai/google_generative_ai.dart';

class GeminiOcrService {
  /// Invokes Gemini-3.5-Flash (the modern platform model) on rasterized image bytes.
  Future<String> extractTextFromPageBytes({
    required Uint8List imageBytes,
    required String apiKey,
  }) async {
    final model = GenerativeModel(
      model: 'gemini-3.5-flash', // Modern high-performance text/vision model
      apiKey: apiKey,
    );

    final content = [
      Content.multi([
        DataPart('image/png', imageBytes),
        TextPart(
          "Extract all text from this page image with absolute high precision. "
          "Maintain original paragraphs, structural layouts, tables (if any, as Markdown), "
          "and punctuation. Do not add summaries or notes.",
        ),
      ]),
    ];

    try {
      final response = await model.generateContent(content);
      return response.text ?? '';
    } catch (e) {
      throw Exception('Gemini API call failed: \$e');
    }
  }
}`
  },
  {
    path: "lib/data/repositories/conversion_repository_impl.dart",
    name: "conversion_repository_impl.dart",
    language: "dart",
    description: "Concrete Implementation of conversion protocols, featuring sequential processing of pages.",
    content: `import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import '../../domain/repositories/conversion_repository.dart';
import '../services/pdf_layout_engine.dart';
import '../services/gemini_ocr_service.dart';
import 'package:pdfx/pdfx.dart';
import 'package:path_provider/path_provider.dart';

class ConversionRepositoryImpl implements ConversionRepository {
  final PdfLayoutEngine _layoutEngine = PdfLayoutEngine();
  final GeminiOcrService _ocrService = GeminiOcrService();

  @override
  Stream<double> convertDocToPdf({
    required String sourcePath,
    required String textContent,
    required String outputFileName,
  }) async* {
    yield 0.1;
    
    // Read local file contents if not directly passed
    String targetText = textContent;
    if (targetText.isEmpty && sourcePath.isNotEmpty) {
      final file = File(sourcePath);
      targetText = await file.readAsString();
    }
    
    yield 0.4;
    
    // Call the layout engine to bundle PDF
    await _layoutEngine.generatePdfFromText(
      text: targetText,
      fileName: outputFileName,
    );
    
    yield 1.0;
  }

  @override
  Stream<double> convertPdfToDoc({
    required String pdfPath,
    required String outputFileName,
    required String apiKey,
    required Function(File) onCompleted,
  }) async* {
    yield 0.05;

    // 1. Load the PDF Document via pdfx for page rasterization
    final pdfDoc = await PdfDocument.openFile(pdfPath);
    final pageCount = pdfDoc.pagesCount;

    if (pageCount == 0) {
      throw Exception("The selected PDF document contains 0 pages.");
    }

    final StringBuffer aggregatedText = StringBuffer();

    // 2. Sequential Streaming & Processing of Pages (Prevents OOM)
    for (int i = 1; i <= pageCount; i++) {
      yield (i - 1) / pageCount * 0.9 + 0.05; // Scaling up to 95% progress

      // Open page sequentially
      final page = await pdfDoc.openPage(i);
      
      // Render page to image bytes (Rasterization)
      final pageImage = await page.render(
        width: page.width * 2, // Double DPI for high OCR accuracy
        height: page.height * 2,
        format: PdfPageImageFormat.png,
      );

      await page.close();

      if (pageImage != null && pageImage.bytes.isNotEmpty) {
        // Compute OCR via Isolate/Thread proxy
        final extractedText = await compute(_runOcrOnIsolate, {
          'bytes': pageImage.bytes,
          'apiKey': apiKey,
          'service': _ocrService,
        });

        aggregatedText.write('--- PAGE \$i ---\\n\\n');
        aggregatedText.write(extractedText);
        aggregatedText.write('\\n\\n');
      }
    }

    // 3. Save resulting Document to Disk
    final directory = await getApplicationDocumentsDirectory();
    final outputFile = File('\${directory.path}/\$outputFileName');
    await outputFile.writeAsString(aggregatedText.toString());

    yield 1.0;
    onCompleted(outputFile);
  }

  /// Top-Level function invoked in isolated background thread
  static Future<String> _runOcrOnIsolate(Map<String, dynamic> args) async {
    final Uint8List bytes = args['bytes'];
    final String apiKey = args['apiKey'];
    final GeminiOcrService service = args['service'];
    return await service.extractTextFromPageBytes(
      imageBytes: bytes,
      apiKey: apiKey,
    );
  }
}`
  },
  {
    path: "lib/presentation/state/conversion_state.dart",
    name: "conversion_state.dart",
    language: "dart",
    description: "Immutable presentation State model mapping conversion progress, routes, and output paths.",
    content: `class ConversionState {
  final bool isLoading;
  final double progress;
  final String? successPath;
  final String? errorMessage;
  final String? sourcePath;
  final String textPreview;

  const ConversionState({
    required this.isLoading,
    required this.progress,
    this.successPath,
    this.errorMessage,
    this.sourcePath,
    required this.textPreview,
  });

  factory ConversionState.initial() {
    return const ConversionState(
      isLoading: false,
      progress: 0.0,
      successPath: null,
      errorMessage: null,
      sourcePath: null,
      textPreview: '',
    );
  }

  ConversionState copyWith({
    bool? isLoading,
    double? progress,
    String? successPath,
    String? errorMessage,
    String? sourcePath,
    String? textPreview,
  }) {
    return ConversionState(
      isLoading: isLoading ?? this.isLoading,
      progress: progress ?? this.progress,
      successPath: successPath ?? this.successPath,
      errorMessage: errorMessage ?? this.errorMessage,
      sourcePath: sourcePath ?? this.sourcePath,
      textPreview: textPreview ?? this.textPreview,
    );
  }
}`
  },
  {
    path: "lib/presentation/state/conversion_notifier.dart",
    name: "conversion_notifier.dart",
    language: "dart",
    description: "Riverpod state notifier coordinating UI interactions with domain repositories.",
    content: `import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/repositories/conversion_repository.dart';
import '../../data/repositories/conversion_repository_impl.dart';
import 'conversion_state.dart';

final conversionRepositoryProvider = Provider<ConversionRepository>((ref) {
  return ConversionRepositoryImpl();
});

final conversionNotifierProvider = StateNotifierProvider<ConversionNotifier, ConversionState>((ref) {
  final repo = ref.watch(conversionRepositoryProvider);
  return ConversionNotifier(repo);
});

class ConversionNotifier extends StateNotifier<ConversionState> {
  final ConversionRepository _repository;

  ConversionNotifier(this._repository) : super(ConversionState.initial());

  void setSourceFile(String path, {String content = ''}) {
    state = state.copyWith(
      sourcePath: path,
      textPreview: content,
      successPath: null,
      errorMessage: null,
    );
  }

  void updateTextContent(String content) {
    state = state.copyWith(textPreview: content);
  }

  void reset() {
    state = ConversionState.initial();
  }

  /// Trigger document to PDF generation
  Future<void> runDocToPdf() async {
    if (state.textPreview.isEmpty) {
      state = state.copyWith(errorMessage: "Please enter or upload text first.");
      return;
    }

    state = state.copyWith(isLoading: true, progress: 0.0, errorMessage: null, successPath: null);

    try {
      final fileName = 'converted_doc_\${DateTime.now().millisecondsSinceEpoch}.pdf';
      
      final progressStream = _repository.convertDocToPdf(
        sourcePath: state.sourcePath ?? '',
        textContent: state.textPreview,
        outputFileName: fileName,
      );

      await for (final p in progressStream) {
        state = state.copyWith(progress: p);
      }

      final directory = await getTemporaryDirectory(); // or path provider
      final savedPath = '\${directory.path}/\$fileName';

      state = state.copyWith(
        isLoading: false,
        isCompleted: true, // or check success
        successPath: savedPath,
        progress: 1.0,
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: 'Conversion failed: \$e');
    }
  }

  /// Trigger AI-Powered OCR conversion
  Future<void> runPdfToDoc({required String apiKey}) async {
    if (state.sourcePath == null || !state.sourcePath!.endsWith('.pdf')) {
      state = state.copyWith(errorMessage: "Please select a valid PDF source file.");
      return;
    }

    if (apiKey.isEmpty) {
      state = state.copyWith(errorMessage: "Please enter your Gemini API Key in configuration.");
      return;
    }

    state = state.copyWith(isLoading: true, progress: 0.0, errorMessage: null, successPath: null);

    try {
      final outName = 'ocr_extracted_\${DateTime.now().millisecondsSinceEpoch}.txt';
      File? finalFile;

      final progressStream = _repository.convertPdfToDoc(
        pdfPath: state.sourcePath!,
        outputFileName: outName,
        apiKey: apiKey,
        onCompleted: (file) {
          finalFile = file;
        },
      );

      await for (final p in progressStream) {
        state = state.copyWith(progress: p);
      }

      if (finalFile != null) {
        final content = await finalFile!.readAsString();
        state = state.copyWith(
          isLoading: false,
          successPath: finalFile!.path,
          textPreview: content,
          progress: 1.0,
        );
      } else {
        throw Exception("Failed to retrieve converted output document file.");
      }
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: 'OCR failed: \$e');
    }
  }
}

// Helper mock functions
Future<Directory> getTemporaryDirectory() async {
  return Directory.systemTemp;
}`
  },
  {
    path: "lib/presentation/screens/converter_screen.dart",
    name: "converter_screen.dart",
    language: "dart",
    description: "High-fidelity Flutter UI with Tab controls, progress updates, URL downloads, and file pickers.",
    content: `import 'dart:io';
import 'package:flutter/material';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:file_picker/file_picker.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import '../state/conversion_notifier.dart';

class ConverterScreen extends ConsumerStatefulWidget {
  const ConverterScreen({super.key});

  @override
  ConsumerState<ConverterScreen> createState() => _ConverterScreenState();
}

class _ConverterScreenState extends ConsumerState<ConverterScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _apiKeyController = TextEditingController();
  final TextEditingController _textInputController = TextEditingController();
  final TextEditingController _urlController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _apiKeyController.dispose();
    _textInputController.dispose();
    _urlController.dispose();
    super.dispose();
  }

  Future<void> _pickFile(ConversionType mode) async {
    final result = await FilePicker.platform.pickFiles(
      type: mode == ConversionType.docToPdf ? FileType.any : FileType.custom,
      allowedExtensions: mode == ConversionType.pdfToDoc ? ['pdf'] : null,
    );

    if (result != null && result.files.single.path != null) {
      final path = result.files.single.path!;
      final file = File(path);
      
      if (mode == ConversionType.docToPdf) {
        final content = await file.readAsString();
        _textInputController.text = content;
        ref.read(conversionNotifierProvider.notifier).setSourceFile(path, content: content);
      } else {
        ref.read(conversionNotifierProvider.notifier).setSourceFile(path);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(conversionNotifierProvider);

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC), // Elegant light slate bg
      appBar: AppBar(
        title: const Text('Bi-Directional AI Document Converter'),
        centerTitle: false,
        elevation: 0,
        backgroundColor: const Color(0xFF0F172A),
        foregroundColor: Colors.white,
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          indicatorColor: Colors.amber,
          tabs: const [
            Tab(icon: Icon(Icons.picture_as_pdf), text: "Document to PDF"),
            Tab(icon: Icon(Icons.document_scanner), text: "PDF to Document (OCR)"),
          ],
        ),
      ),
      body: Column(
        children: [
          // API Key Configuration Header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            color: const Color(0xFF1E293B),
            child: Row(
              children: [
                const Icon(Icons.key, color: Colors.amber, size: 20),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _apiKeyController,
                    obscureText: true,
                    style: const TextStyle(color: Colors.white, fontSize: 13),
                    decoration: const InputDecoration(
                      hintText: "Enter Gemini API Key to enable OCR",
                      hintStyle: TextStyle(color: Colors.white38),
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ],
            ),
          ),

          if (state.isLoading)
            LinearProgressIndicator(
              value: state.progress,
              backgroundColor: Colors.grey[200],
              color: Colors.indigo,
              minHeight: 5,
            ),

          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                // TAB 1: Doc to PDF Panel
                _buildDocToPdfTab(state),

                // TAB 2: PDF to Doc OCR Panel
                _buildPdfToDocTab(state),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDocToPdfTab(dynamic state) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => _pickFile(ConversionType.docToPdf),
                  icon: const Icon(Icons.file_upload),
                  label: const Text('Upload Local Text Doc'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.slate[200],
                    foregroundColor: Colors.slate[800],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey[300]!),
              ),
              child: TextField(
                controller: _textInputController,
                maxLines: null,
                keyboardType: TextInputType.multiline,
                onChanged: (text) => ref.read(conversionNotifierProvider.notifier).updateTextContent(text),
                decoration: const InputDecoration(
                  hintText: "Type, paste, or upload text content here...",
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.all(16),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (state.successPath != null)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.emerald[50],
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: Colors.emerald[200]!),
              ),
              child: Row(
                children: [
                  const Icon(Icons.check_circle, color: Colors.emerald),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'PDF saved to: \${state.successPath}',
                      style: TextStyle(color: Colors.emerald[900], fontSize: 13),
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: state.isLoading ? null : () => ref.read(conversionNotifierProvider.notifier).runDocToPdf(),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF0F172A),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            child: state.isLoading
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('Convert & Build PDF Document'),
          ),
        ],
      ),
    );
  }

  Widget _buildPdfToDocTab(dynamic state) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => _pickFile(ConversionType.pdfToDoc),
                  icon: const Icon(Icons.picture_as_pdf),
                  label: const Text('Select Local PDF'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.slate[200],
                    foregroundColor: Colors.slate[800],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          
          // PDF Preview Frame
          Expanded(
            child: state.sourcePath != null
                ? Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey[350]!),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: SfPdfViewer.file(File(state.sourcePath!)),
                  )
                : Container(
                    decoration: BoxDecoration(
                      color: Colors.grey[100],
                      border: Border.all(color: Colors.grey[300]!, style: BorderStyle.dashed),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.picture_as_pdf, size: 48, color: Colors.grey),
                          SizedBox(height: 8),
                          Text('No PDF document loaded for OCR', style: TextStyle(color: Colors.grey)),
                        ],
                      ),
                    ),
                  ),
          ),
          
          const SizedBox(height: 12),
          
          if (state.errorMessage != null)
            Text(
              state.errorMessage!,
              style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: state.isLoading
                ? null
                : () => ref.read(conversionNotifierProvider.notifier).runPdfToDoc(apiKey: _apiKeyController.text),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.indigo,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            child: state.isLoading
                ? Text('Processing Page OCR (\${(state.progress * 100).toStringAsFixed(0)}%)')
                : const Text('Convert PDF via Google Gemini OCR'),
          ),
        ],
      ),
    );
  }
}`
  },
  {
    path: "test/conversion_test.dart",
    name: "conversion_test.dart",
    language: "dart",
    description: "Robust Unit test testing both Doc-to-PDF and AI-OCR-PDF conversion flows with mock assertions.",
    content: `import 'dart:async';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_pdf_converter/domain/repositories/conversion_repository.dart';

class MockConversionRepository implements ConversionRepository {
  @override
  Stream<double> convertDocToPdf({
    required String sourcePath,
    required String textContent,
    required String outputFileName,
  }) async* {
    yield 0.1;
    yield 0.5;
    yield 1.0;
  }

  @override
  Stream<double> convertPdfToDoc({
    required String pdfPath,
    required String outputFileName,
    required String apiKey,
    required Function(File) onCompleted,
  }) async* {
    yield 0.2;
    yield 0.6;
    yield 1.0;
    onCompleted(File('/mock/path/\$outputFileName'));
  }
}

void main() {
  group('Bi-directional Conversion Unit Tests', () {
    late MockConversionRepository repository;

    setUp(() {
      repository = MockConversionRepository();
    });

    test('Document to PDF should yield sequential loading progress to completion', () async {
      final progressList = <double>[];
      
      final stream = repository.convertDocToPdf(
        sourcePath: 'mock_doc.txt',
        textContent: 'Hello Universal Flutter Test Content',
        outputFileName: 'mock_out.pdf',
      );

      await for (final progress in stream) {
        progressList.add(progress);
      }

      expect(progressList, contains(0.1));
      expect(progressList, contains(0.5));
      expect(progressList.last, equals(1.0));
    });

    test('PDF to Doc OCR should sequentially stream page completion and trigger completion callback', () async {
      final progressList = <double>[];
      File? completedFile;

      final stream = repository.convertPdfToDoc(
        pdfPath: 'scanned_doc.pdf',
        outputFileName: 'mock_text.txt',
        apiKey: 'AIzaSy_Mock_Key',
        onCompleted: (file) {
          completedFile = file;
        },
      );

      await for (final progress in stream) {
        progressList.add(progress);
      }

      expect(progressList, contains(0.2));
      expect(progressList, contains(0.6));
      expect(progressList.last, equals(1.0));
      expect(completedFile, isNotNull);
      expect(completedFile!.path, endsWith('mock_text.txt'));
    });
  });
}`
  }
];

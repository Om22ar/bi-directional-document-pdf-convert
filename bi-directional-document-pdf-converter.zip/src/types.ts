export interface FlutterFile {
  path: string;
  name: string;
  language: "yaml" | "dart" | "xml" | "markdown";
  description: string;
  content: string;
}

export interface SampleDoc {
  id: string;
  name: string;
  type: "text" | "scanned_pdf";
  content: string; // Plain text or base64 image URL (placeholder for simulated scanning)
  description: string;
  imageUrl?: string; // base64 or URL for visual rendering
}
